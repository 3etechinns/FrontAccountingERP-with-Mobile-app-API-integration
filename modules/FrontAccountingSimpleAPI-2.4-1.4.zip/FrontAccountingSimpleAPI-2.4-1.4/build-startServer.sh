#!/bin/bash
php -S localhost:8000 -t ../..
